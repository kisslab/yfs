#include "jsl_log.h"

int JSL_DEBUG_LEVEL = 0;
void
jsl_set_debug(int level) {
	JSL_DEBUG_LEVEL = level;
}


